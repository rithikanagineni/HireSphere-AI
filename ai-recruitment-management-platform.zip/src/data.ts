import { Job, CandidateProfile, Application, Template, Company, User, Interview, NotificationLog, Analytics, ResumeParsedData } from './types';

export const mockCompanies: Company[] = [
  {
    id: 'comp1',
    name: 'NovaStack AI',
    logo: 'https://picsum.photos/id/1/128/128',
    description: 'Building next-generation AI-powered enterprise solutions with a focus on scalable distributed systems.',
    industry: 'Artificial Intelligence',
    website: 'https://novastack.ai',
    location: 'San Francisco, CA',
    employeeCount: 250,
    foundedYear: 2020,
    recruiterIds: ['rec1'],
    verified: true,
    status: 'approved'
  },
  {
    id: 'comp2',
    name: 'Vanguard Labs',
    logo: 'https://picsum.photos/id/20/128/128',
    description: 'AI-first fintech solutions transforming digital banking and payments.',
    industry: 'Fintech',
    website: 'https://vanguardlabs.io',
    location: 'New York, NY',
    employeeCount: 180,
    foundedYear: 2019,
    recruiterIds: ['rec2'],
    verified: true,
    status: 'approved'
  },
  {
    id: 'comp3',
    name: 'DataForge',
    logo: 'https://picsum.photos/id/30/128/128',
    description: 'Data infrastructure and analytics platform for modern enterprises.',
    industry: 'Data & Analytics',
    website: 'https://dataforge.io',
    location: 'Austin, TX',
    employeeCount: 120,
    foundedYear: 2021,
    recruiterIds: ['rec3'],
    verified: true,
    status: 'approved'
  }
];

export const mockUsers: User[] = [
  {
    id: 'admin1',
    name: 'Nagineni Rithika',
    email: 'rithikanagineni@gmail.com',
    password: 'Rithika@123',
    role: 'admin',
    createdAt: new Date('2024-01-01')
  }
];

export const mockJobs: Job[] = [
  {
    id: 'job1',
    title: 'AI Engineer',
    companyId: 'comp1',
    companyName: 'NovaStack AI',
    companyLogo: 'https://picsum.photos/id/1/128/128',
    description: 'We are looking for an AI Engineer to develop and deploy machine learning models at scale. You will work on LLMs, recommendation systems, and AI-powered features.',
    department: 'Engineering',
    requirements: ['Python', 'Machine Learning', 'Deep Learning', 'NLP', 'TensorFlow/PyTorch'],
    preferredSkills: ['LLMs', 'RAG Systems', 'AWS SageMaker'],
    location: 'San Francisco, CA',
    salaryMin: 150000,
    salaryMax: 220000,
    salaryCurrency: 'USD',
    type: 'Full-time',
    workMode: 'Hybrid',
    experienceLevel: 'Senior',
    experienceYears: '3-5 years',
    postedDate: new Date('2025-01-10'),
    applicationDeadline: new Date('2026-03-15'),
    status: 'Open',
    applicationsCount: 45,
    approved: true
  },
  {
    id: 'job2',
    title: 'Frontend Developer',
    companyId: 'comp1',
    companyName: 'NovaStack AI',
    companyLogo: 'https://picsum.photos/id/1/128/128',
    description: 'Join our UI team to build intuitive and performant user interfaces for our AI products. Work with React, TypeScript, and modern frontend tooling.',
    department: 'Engineering',
    requirements: ['React', 'TypeScript', 'Tailwind CSS', 'JavaScript', 'HTML/CSS'],
    preferredSkills: ['Next.js', 'GraphQL', 'Storybook'],
    location: 'Remote',
    salaryMin: 120000,
    salaryMax: 180000,
    salaryCurrency: 'USD',
    type: 'Full-time',
    workMode: 'Remote',
    experienceLevel: 'Mid',
    experienceYears: '2-4 years',
    postedDate: new Date('2025-01-12'),
    applicationDeadline: new Date('2026-04-01'),
    status: 'Open',
    applicationsCount: 38,
    approved: true
  },
  {
    id: 'job3',
    title: 'Product Marketing Manager',
    companyId: 'comp2',
    companyName: 'Vanguard Labs',
    companyLogo: 'https://picsum.photos/id/20/128/128',
    description: 'Drive go-to-market strategy for our AI-powered investment platform. Work closely with product, sales, and engineering teams.',
    department: 'Marketing',
    requirements: ['B2B SaaS Marketing', 'Product Positioning', 'Content Strategy', 'Market Research'],
    preferredSkills: ['Financial Services', 'Analytics Tools'],
    location: 'New York, NY',
    salaryMin: 115000,
    salaryMax: 155000,
    salaryCurrency: 'USD',
    type: 'Full-time',
    workMode: 'Office',
    experienceLevel: 'Mid',
    experienceYears: '3-5 years',
    postedDate: new Date('2025-01-15'),
    applicationDeadline: new Date('2026-03-30'),
    status: 'Open',
    applicationsCount: 28,
    approved: true
  },
  {
    id: 'job4',
    title: 'Backend Engineer - Python',
    companyId: 'comp3',
    companyName: 'DataForge',
    companyLogo: 'https://picsum.photos/id/30/128/128',
    description: 'Join our core platform team building scalable distributed data systems. Expertise with Python, FastAPI, PostgreSQL and AWS is a must.',
    department: 'Engineering',
    requirements: ['Python', 'FastAPI', 'PostgreSQL', 'AWS', 'Docker'],
    preferredSkills: ['Kubernetes', 'Apache Kafka', 'Redis'],
    location: 'Austin, TX',
    salaryMin: 130000,
    salaryMax: 195000,
    salaryCurrency: 'USD',
    type: 'Full-time',
    workMode: 'Hybrid',
    experienceLevel: 'Senior',
    experienceYears: '4-6 years',
    postedDate: new Date('2025-01-18'),
    applicationDeadline: new Date('2026-04-15'),
    status: 'Open',
    applicationsCount: 31,
    approved: true
  },
  {
    id: 'job5',
    title: 'Data Scientist Intern',
    companyId: 'comp3',
    companyName: 'DataForge',
    companyLogo: 'https://picsum.photos/id/30/128/128',
    description: 'Exciting internship opportunity to work on real-world data science problems.',
    department: 'Data Science',
    requirements: ['Python', 'SQL', 'Statistics', 'Machine Learning Basics'],
    preferredSkills: ['Jupyter', 'Pandas', 'Scikit-learn'],
    location: 'Austin, TX',
    salaryMin: 40000,
    salaryMax: 60000,
    salaryCurrency: 'USD',
    type: 'Internship',
    workMode: 'Office',
    experienceLevel: 'Entry',
    experienceYears: '0-1 years',
    postedDate: new Date('2025-01-20'),
    applicationDeadline: new Date('2026-05-01'),
    status: 'Open',
    applicationsCount: 67,
    approved: true
  }
];

export const mockCandidates: CandidateProfile[] = [];

export const mockApplications: Application[] = [];

// Templates stored as plain strings (no template literals to avoid TS interpolation)
const makeOfferTemplate = (style: string): string => {
  if (style === 'Corporate') {
    return '<div style="font-family: Times New Roman, serif; max-width: 700px; margin: 40px auto; padding: 40px; border: 2px solid #1e293b;"><div style="text-align: center; border-bottom: 3px double #1e293b; padding-bottom: 20px; margin-bottom: 30px;"><h1 style="font-size: 26px; letter-spacing: 2px;">{{companyName}}</h1><p style="font-size: 14px; color: #475569;">OFFICIAL LETTER OF EMPLOYMENT</p></div><p>Date: {{joiningDate}}</p><p>To,</p><p><strong>{{candidateName}}</strong></p><p style="margin-top: 30px;">Subject: Offer of Employment for the position of {{role}}</p><p style="margin-top: 20px; line-height: 1.8;">Dear {{candidateName}},</p><p style="margin: 20px 0; line-height: 1.8;">We are pleased to offer you the position of <strong>{{role}}</strong> with {{companyName}}. We were impressed with your qualifications and believe you will make a valuable contribution to our organization.</p><div style="margin: 30px 0; padding: 20px; border: 1px solid #cbd5e1;"><p><strong>Annual Compensation:</strong> ${{salary}}</p><p><strong>Start Date:</strong> {{joiningDate}}</p><p><strong>Location:</strong> {{workLocation}}</p></div><p style="margin-top: 40px;">Please sign below to indicate your acceptance.</p><div style="margin-top: 60px;"><p>_________________________</p><p>Candidate Signature</p></div><div style="margin-top: 30px;"><p>_________________________</p><p>HR Representative</p></div></div>';
  }
  if (style === 'Enterprise') {
    return '<div style="font-family: Georgia, serif; max-width: 750px; margin: 40px auto; padding: 50px;"><div style="text-align: center;"><h1 style="font-size: 32px; letter-spacing: 3px; margin: 0;">{{companyName}}</h1><p style="font-size: 12px; letter-spacing: 2px; color: #64748b;">CONFIDENTIAL</p></div><div style="margin-top: 40px;"><p>Ref: OFF/{{joiningDate}}/{{candidateName}}</p><p>Date: {{joiningDate}}</p></div><p style="margin-top: 30px;"><strong>Dear {{candidateName}},</strong></p><p style="margin: 20px 0; line-height: 2;">Following your interview and assessment, we are delighted to extend this offer of employment for the role of <strong>{{role}}</strong>.</p><div style="margin: 30px 0; padding: 30px; background: linear-gradient(135deg, #f8fafc, #f1f5f9); border-radius: 8px;"><h3>Offer Details</h3><table style="width: 100%; border-collapse: collapse;"><tr style="border-bottom: 1px solid #e2e8f0;"><td style="padding: 12px 0;">Position</td><td style="text-align: right;"><strong>{{role}}</strong></td></tr><tr style="border-bottom: 1px solid #e2e8f0;"><td style="padding: 12px 0;">Annual Base Salary</td><td style="text-align: right;"><strong>${{salary}}</strong></td></tr><tr style="border-bottom: 1px solid #e2e8f0;"><td style="padding: 12px 0;">Start Date</td><td style="text-align: right;"><strong>{{joiningDate}}</strong></td></tr><tr style="border-bottom: 1px solid #e2e8f0;"><td style="padding: 12px 0;">Location</td><td style="text-align: right;"><strong>{{workLocation}}</strong></td></tr></table></div><p style="line-height: 1.8;">This offer is valid for 7 business days. Please indicate your acceptance by signing below.</p><div style="margin-top: 60px; display: flex; gap: 40px;"><div style="flex: 1;"><p style="border-top: 1px solid #000; padding-top: 8px; font-size: 12px;">HR Representative</p></div><div style="flex: 1;"><p style="border-top: 1px solid #000; padding-top: 8px; font-size: 12px;">Candidate</p></div></div></div>';
  }
  // Modern Startup (default)
  return '<div style="font-family: Inter, system-ui; max-width: 700px; margin: 40px auto; padding: 40px;"><div style="text-align: center; margin-bottom: 30px;"><h1 style="color: #111827; font-size: 28px; margin-top: 20px;">Offer of Employment</h1><p style="color: #64748b;">{{companyName}}</p></div><p style="margin: 24px 0; line-height: 1.7;">Dear <strong>{{candidateName}}</strong>,</p><p style="margin: 24px 0; line-height: 1.7;">We are excited to offer you the position of <strong>{{role}}</strong> at <strong>{{companyName}}</strong>.</p><div style="background: #f8fafc; border-radius: 16px; padding: 28px; margin: 30px 0;"><h3 style="margin: 0 0 20px 0; font-size: 16px;">Compensation Package</h3><table style="width: 100%; border-collapse: collapse;"><tr><td style="padding: 8px 0; color: #64748b;">Annual Salary</td><td style="text-align: right; font-weight: 600;">${{salary}}/year</td></tr><tr><td style="padding: 8px 0; color: #64748b;">Joining Date</td><td style="text-align: right; font-weight: 600;">{{joiningDate}}</td></tr><tr><td style="padding: 8px 0; color: #64748b;">Work Location</td><td style="text-align: right; font-weight: 600;">{{workLocation}}</td></tr></table></div><div style="margin: 24px 0; line-height: 1.7;"><h3 style="font-size: 16px;">Terms & Conditions</h3><p>{{terms}}</p></div><p style="margin: 40px 0 0 0; line-height: 1.7;">We look forward to welcoming you aboard!</p><div style="margin-top: 50px; display: flex; justify-content: space-between;"><div><p style="font-weight: 600; margin: 0;">Best regards,</p><p style="margin: 4px 0 0 0;">{{companyName}} Team</p></div></div><div style="margin-top: 30px; padding: 16px; background: #f1f5f9; border-radius: 12px; font-size: 12px; color: #64748b;"><strong>Candidate Acceptance:</strong> I, {{candidateName}}, accept the offer.<div style="margin-top: 12px; display: flex; gap: 20px;"><span>Signature: _________________</span><span>Date: _________________</span></div></div></div>';
};

const makeExperienceTemplate = (): string => {
  return '<div style="font-family: Inter, system-ui; max-width: 700px; margin: 40px auto; padding: 40px; border: 1px solid #e2e8f0;"><div style="text-align: center; border-bottom: 2px solid #111827; padding-bottom: 20px; margin-bottom: 30px;"><h2 style="font-size: 26px; margin: 0;">Experience Certificate</h2></div><p>This is to certify that <strong>{{candidateName}}</strong> worked with <strong>{{companyName}}</strong> as <strong>{{role}}</strong> from <strong>{{startDate}}</strong> to <strong>{{endDate}}</strong>.</p><p style="margin: 20px 0; line-height: 1.7;">{{performance}}</p><div style="margin-top: 60px; text-align: right;"><div style="border-top: 2px solid #111827; width: 250px; margin-left: auto; padding-top: 10px;"><p style="margin: 0; font-weight: 600;">HR Director</p><p style="margin: 4px 0 0 0; font-size: 12px; color: #64748b;">{{companyName}}</p></div></div></div>';
};

const makeRelievingTemplate = (): string => {
  return '<div style="font-family: Georgia, serif; max-width: 700px; margin: 40px auto; padding: 40px; border: 2px solid #334155;"><div style="text-align: center; margin-bottom: 30px;"><h2 style="font-size: 24px;">Relieving Certificate</h2></div><p>This is to certify that <strong>{{candidateName}}</strong> has been relieved from their duties as <strong>{{role}}</strong> at <strong>{{companyName}}</strong> effective <strong>{{endDate}}</strong>.</p><p style="margin: 20px 0; line-height: 1.7;">During their employment from {{startDate}} to {{endDate}}, they conducted themselves with professionalism and integrity.</p><p style="margin: 20px 0;">Reason for leaving: {{reason}}</p><p>We wish them all the best in their future endeavors.</p><div style="margin-top: 60px;"><p>_________________________</p><p>Authorized Signatory</p></div></div>';
};

const makePayslipTemplate = (style: string): string => {
  if (style === 'Corporate') {
    return '<div style="font-family: Segoe UI, sans-serif; width: 800px; margin: 20px auto; padding: 35px; border: 1px solid #cbd5e1;"><div style="display: flex; justify-content: space-between; border-bottom: 3px solid #1e293b; padding-bottom: 15px;"><div><h1 style="font-size: 20px; margin: 0; letter-spacing: 1px;">{{companyName}}</h1></div><div style="text-align: right;"><div style="font-weight: 700;">{{candidateName}}</div><div style="font-size: 11px;">EMP-{{employeeId}}</div></div></div><div style="text-align: center; margin: 20px 0; font-size: 18px; font-weight: 700;">PAYSLIP -- {{month}} {{year}}</div><table style="width: 100%; border-collapse: collapse; margin-top: 20px;"><tr style="background: #f1f5f9;"><th style="padding: 12px; text-align: left;">Component</th><th style="padding: 12px; text-align: right;">Amount</th></tr><tr><td style="padding: 10px; border-bottom: 1px solid #e2e8f0;">Basic Salary</td><td style="text-align: right; padding: 10px;">{{basicSalary}}</td></tr><tr><td style="padding: 10px; border-bottom: 1px solid #e2e8f0;">House Rent Allowance</td><td style="text-align: right; padding: 10px;">{{hra}}</td></tr><tr><td style="padding: 10px; border-bottom: 1px solid #e2e8f0;">Performance Bonus</td><td style="text-align: right; padding: 10px;">{{bonus}}</td></tr><tr><td style="padding: 10px; border-bottom: 1px solid #e2e8f0;">Special Allowances</td><td style="text-align: right; padding: 10px;">{{allowances}}</td></tr><tr style="background: #f8fafc;"><td style="padding: 12px; font-weight: 700;">Gross Earnings</td><td style="text-align: right; padding: 12px; font-weight: 700;">{{totalEarnings}}</td></tr><tr><td style="padding: 10px; border-bottom: 1px solid #e2e8f0;">Tax Deducted at Source</td><td style="text-align: right; padding: 10px; color: #e11d48;">-{{taxDeduction}}</td></tr><tr><td style="padding: 10px; border-bottom: 1px solid #e2e8f0;">Provident Fund</td><td style="text-align: right; padding: 10px; color: #e11d48;">-{{pfDeduction}}</td></tr><tr style="background: #1e293b; color: white;"><td style="padding: 14px; font-weight: 700;">NET PAYABLE</td><td style="text-align: right; padding: 14px; font-weight: 700; font-size: 18px;">{{netSalary}}</td></tr></table><div style="margin-top: 20px; font-size: 10px; color: #94a3b8; text-align: center;">This is computer generated. No signature required.</div></div>';
  }
  // Modern Startup (default)
  return '<div style="font-family: Inter, system-ui; width: 800px; margin: 20px auto; padding: 30px; background: white;"><div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #111827; padding-bottom: 16px;"><div><h1 style="font-size: 22px; margin: 0;">{{companyName}}</h1><p style="color: #64748b; margin: 2px 0 0 0; font-size: 13px;">Payslip for {{month}} {{year}}</p></div><div style="text-align: right;"><div style="font-weight: 700;">{{candidateName}}</div><div style="font-size: 12px; color: #64748b;">Employee ID: {{employeeId}}</div><div style="font-size: 12px; color: #64748b;">Department: {{department}}</div></div></div><div style="margin: 30px 0; display: grid; grid-template-columns: 1fr 1fr; gap: 40px;"><div><div style="font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;">Earnings</div><div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #e2e8f0;"><span>Basic Salary</span><span>{{basicSalary}}</span></div><div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #e2e8f0;"><span>HRA</span><span>{{hra}}</span></div><div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #e2e8f0;"><span>Bonus</span><span>{{bonus}}</span></div><div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #e2e8f0;"><span>Allowances</span><span>{{allowances}}</span></div><div style="display: flex; justify-content: space-between; padding: 14px 0; font-weight: 700; font-size: 16px;"><span>Total Earnings</span><span>{{totalEarnings}}</span></div></div><div><div style="font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;">Deductions</div><div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #e2e8f0;"><span>Income Tax</span><span>{{taxDeduction}}</span></div><div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #e2e8f0;"><span>Provident Fund</span><span>{{pfDeduction}}</span></div><div style="display: flex; justify-content: space-between; padding: 14px 0; font-weight: 700; font-size: 16px; color: #e11d48;"><span>Total Deductions</span><span>{{totalDeductions}}</span></div></div></div><div style="background: #111827; color: white; padding: 20px; border-radius: 12px; text-align: center; font-size: 24px; font-weight: 700;">NET PAY: {{netSalary}}</div><div style="margin-top: 30px; text-align: center; font-size: 11px; color: #94a3b8;">This is a computer-generated payslip and does not require a physical signature.</div></div>';
};

export const mockTemplates: Template[] = [
  { id: 'tpl1', name: 'Modern Startup Offer Letter', type: 'offer', style: 'Modern Startup', content: makeOfferTemplate('Modern Startup') },
  { id: 'tpl2', name: 'Corporate Offer Letter', type: 'offer', style: 'Corporate', content: makeOfferTemplate('Corporate') },
  { id: 'tpl3', name: 'Enterprise Offer Letter', type: 'offer', style: 'Enterprise', content: makeOfferTemplate('Enterprise') },
  { id: 'tpl4', name: 'Standard Experience Letter', type: 'experience', style: 'Modern Startup', content: makeExperienceTemplate() },
  { id: 'tpl5', name: 'Standard Relieving Letter', type: 'relieving', style: 'Corporate', content: makeRelievingTemplate() },
  { id: 'tpl6', name: 'Monthly Payslip', type: 'payslip', style: 'Modern Startup', content: makePayslipTemplate('Modern Startup') },
  { id: 'tpl7', name: 'Detailed Corporate Payslip', type: 'payslip', style: 'Corporate', content: makePayslipTemplate('Corporate') }
];

export const mockInterviews: Interview[] = [
  {
    id: 'int1',
    applicationId: 'app4',
    candidateName: 'Elena Petrova',
    candidateId: 'cand3',
    interviewerName: 'Alex Rivera',
    date: '2025-02-05',
    time: '10:30',
    type: 'Video',
    link: 'https://meet.google.com/abc-defg-hij',
    status: 'Confirmed',
    recruiterId: 'rec1'
  }
];

export const mockNotifications: NotificationLog[] = [
  {
    id: 'not1',
    applicationId: 'app1',
    candidateName: 'Rithika Sharma',
    type: 'email',
    message: 'Congratulations! You have been shortlisted for Frontend Developer at NovaStack AI',
    sentAt: new Date('2025-01-15'),
    status: 'sent'
  },
  {
    id: 'not2',
    applicationId: 'app1',
    candidateName: 'Rithika Sharma',
    type: 'whatsapp',
    message: 'Your application status has been updated to "Shortlisted" for Frontend Developer at NovaStack AI',
    sentAt: new Date('2025-01-15'),
    status: 'sent'
  }
];

export const mockAnalytics: Analytics = {
  totalJobs: 5,
  totalApplicants: 209,
  averageHiringTime: 28,
  shortlistRate: 32,
  interviewConversion: 58,
  applicationsPerMonth: [
    { month: 'Jan', count: 45 },
    { month: 'Feb', count: 52 },
    { month: 'Mar', count: 38 },
    { month: 'Apr', count: 41 },
    { month: 'May', count: 33 }
  ],
  hiringFunnel: [
    { stage: 'Applied', count: 209 },
    { stage: 'AI Screened', count: 185 },
    { stage: 'Shortlisted', count: 67 },
    { stage: 'Interviewed', count: 39 },
    { stage: 'Offered', count: 14 },
    { stage: 'Accepted', count: 8 }
  ],
  topSkills: [
    { skill: 'Python', count: 89 },
    { skill: 'JavaScript', count: 76 },
    { skill: 'React', count: 65 },
    { skill: 'Machine Learning', count: 52 },
    { skill: 'AWS', count: 48 },
    { skill: 'TypeScript', count: 42 }
  ]
};

export const demoResumeParsedData: ResumeParsedData = {
  name: 'Rithika Sharma',
  email: 'rithika.sharma@email.com',
  skills: ['Python', 'Java', 'React', 'AI', 'Node.js', 'TypeScript', 'Machine Learning'],
  education: ['B.Tech IT - Stanford University'],
  experience: [
    { company: 'XYZ Technologies', role: 'Software Intern', duration: 'Jan 2026 - June 2026', responsibilities: ['Developed React components', 'Built APIs', 'Worked with AI tools'] }
  ],
  projects: ['AI Chatbot', 'Recruitment Portal', 'E-commerce Platform'],
  certifications: ['AWS Cloud Practitioner', 'Google Analytics Individual Qualification'],
  previousCompanies: ['XYZ Technologies']
};
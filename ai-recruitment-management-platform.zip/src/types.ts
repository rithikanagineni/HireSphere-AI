export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'candidate' | 'recruiter' | 'admin';
  phone?: string;
  company?: string;
  companyId?: string;
  avatar?: string;
  verified?: boolean;
  createdAt?: Date;
  approvalStatus?: 'pending' | 'approved' | 'rejected';
}

export interface Company {
  id: string;
  name: string;
  logo: string;
  description: string;
  industry: string;
  website?: string;
  location?: string;
  employeeCount?: number;
  foundedYear?: number;
  recruiterIds: string[];
  verified?: boolean;
  status?: 'pending' | 'approved' | 'rejected';
}

export interface Job {
  id: string;
  title: string;
  companyId: string;
  companyName: string;
  companyLogo?: string;
  description: string;
  department?: string;
  requirements: string[];
  preferredSkills?: string[];
  location: string;
  salaryMin: number;
  salaryMax: number;
  salaryCurrency?: string;
  type: 'Full-time' | 'Part-time' | 'Contract' | 'Internship';
  workMode?: 'Remote' | 'Hybrid' | 'Office';
  experienceLevel: 'Entry' | 'Mid' | 'Senior';
  experienceYears?: string;
  postedDate: Date;
  applicationDeadline?: Date;
  status: 'Open' | 'Closed';
  applicationsCount: number;
  approved?: boolean;
}

export interface CandidateProfile {
  id: string;
  userId: string;
  name: string;
  email?: string;
  phone?: string;
  title: string;
  employmentType?: 'Full Time' | 'Internship' | 'Freelance';
  currentCompany?: string;
  location: string;
  experience: number;
  expectedSalary?: string;
  noticePeriod?: string;
  education: string;
  educationDetails?: EducationEntry[];
  skills: string[];
  resumeUrl?: string;
  resumeParsedData?: ResumeParsedData;
  bio?: string;
  avatar?: string;
  linkedin?: string;
  portfolio?: string;
  experienceEntries?: ExperienceEntry[];
}

export interface EducationEntry {
  degree: string;
  college: string;
  year: string;
  cgpa: string;
}

export interface ExperienceEntry {
  company: string;
  role: string;
  duration: string;
  responsibilities: string[];
}

export interface ResumeParsedData {
  name?: string;
  email?: string;
  skills: string[];
  education: string[];
  experience: ExperienceEntry[];
  projects: string[];
  certifications: string[];
  previousCompanies: string[];
}

export interface Application {
  id: string;
  jobId: string;
  candidateId: string;
  candidateName: string;
  candidateEmail?: string;
  candidateAvatar?: string;
  jobTitle?: string;
  companyName?: string;
  resumeUsed?: string;
  matchScore: number;
  aiMatchReason?: string[];
  aiMissingSkills?: string[];
  status: ApplicationStatus;
  appliedDate: Date;
  notes?: string;
}

export type ApplicationStatus = 
  | 'Applied' 
  | 'AI Screening' 
  | 'Shortlisted' 
  | 'Rejected' 
  | 'On Hold' 
  | 'Interview Scheduled' 
  | 'Interview Confirmed'
  | 'Offered' 
  | 'Offer Accepted'
  | 'Joined';

export interface Template {
  id: string;
  name: string;
  type: 'offer' | 'experience' | 'relieving' | 'payslip';
  style: 'Modern Startup' | 'Corporate' | 'Enterprise';
  content: string;
  companyId?: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'email' | 'whatsapp' | 'telegram';
  subject?: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

export interface Interview {
  id: string;
  applicationId: string;
  candidateName: string;
  candidateId?: string;
  interviewerName?: string;
  date: string;
  time: string;
  type?: 'Video' | 'Phone' | 'In-person';
  link?: string;
  status: 'Proposed' | 'Confirmed' | 'Completed' | 'Cancelled';
  recruiterId?: string;
}

export interface Analytics {
  totalJobs: number;
  totalApplicants: number;
  averageHiringTime: number;
  shortlistRate: number;
  interviewConversion: number;
  applicationsPerMonth: { month: string; count: number }[];
  hiringFunnel: { stage: string; count: number }[];
  topSkills: { skill: string; count: number }[];
}

export interface EsignRecord {
  id: string;
  documentId: string;
  documentType: 'offer' | 'experience' | 'relieving';
  candidateName: string;
  signature: string;
  signedDate: Date;
  ipAddress?: string;
  documentVersion?: string;
  acceptedBy: string;
}

export interface LetterFormData {
  role: string;
  salary: string;
  joiningDate: string;
  month: string;
  year: string;
  startDate: string;
  endDate: string;
  reason: string;
  basicSalary: string;
  hra: string;
  bonus: string;
  allowances: string;
  taxDeduction: string;
  pfDeduction: string;
  employeeId: string;
  department: string;
  netSalary: string;
  totalEarnings: string;
  totalDeductions: string;
  performance: string;
  terms: string;
}

export interface NotificationLog {
  id: string;
  applicationId: string;
  candidateName: string;
  type: 'email' | 'whatsapp' | 'telegram';
  message: string;
  sentAt: Date;
  status: 'sent' | 'failed';
}

export interface ReferenceCheck {
  id: string;
  candidateId: string;
  candidateName: string;
  refereeEmail: string;
  status: 'requested' | 'submitted';
  submittedAt?: Date;
  feedback?: string;
}